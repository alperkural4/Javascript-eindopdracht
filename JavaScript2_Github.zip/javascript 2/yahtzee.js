let dice = [];
let rollsLeft = 3;
let scores = {
  1: 0,
  2: 0,
  3: 0,
  4: 0,
  5: 0,
  6: 0,
  threeOfAKind: 0,
  fourOfAKind: 0,
  fullHouse: 0,
  yahtzee: 0,
  bonus: 0,
};
let lockedDice = [];
let lockedScores = new Set();
let scoreSelected = false;




function rollDice() {
  if (rollsLeft > 0) {
    for (let i = 0; i < 5; i++) {
      if (!lockedDice.includes(i)) {
        let die = Math.floor(Math.random() * 6) + 1;
        dice[i] = die;
        document.getElementById(`die${i + 1}`).src = `dices/Dice_${die}.png`;
        document.getElementById(`die${i + 1}`).classList.remove("locked");
      }
    }
    rollsLeft--;
    calculateScores();
    scoreSelected = false;
    document.getElementById("rollButton").disabled = true;
  }
}


//vergerendelt of ontgrendelt een dobbelsteen als je erop klikt
function toggleLockDie(index) {
  const indexOfLockedDie = lockedDice.indexOf(index);
  const diceElement = document.getElementById(`die${index + 1}`);

  if (indexOfLockedDie !== -1) {
    lockedDice.splice(indexOfLockedDie, 1);
    diceElement.classList.remove("locked");
  } else if (!diceElement.classList.contains("locked")) {
    lockedDice.push(index);
    diceElement.classList.add("locked");
  }
}

for (let i = 1; i <= 5; i++) {
  const diceElement = document.getElementById(`die${i}`);
  diceElement.addEventListener("click", () => toggleLockDie(i - 1));
}

//het resetten van de game
function resetGame() {
  location.reload();
}

document.getElementById("totalscore").textContent("alper");

function calculateScores() {
  if (!lockedScores.has("1"))
    scores[1] = dice
      .filter((die) => die === 1)
      .reduce((sum, die) => sum + die, 0);
  if (!lockedScores.has("2"))
    scores[2] = dice
      .filter((die) => die === 2)
      .reduce((sum, die) => sum + die, 0);
  if (!lockedScores.has("3"))
    scores[3] = dice
      .filter((die) => die === 3)
      .reduce((sum, die) => sum + die, 0);
  if (!lockedScores.has("4"))
    scores[4] = dice
      .filter((die) => die === 4)
      .reduce((sum, die) => sum + die, 0);
  if (!lockedScores.has("5"))
    scores[5] = dice
      .filter((die) => die === 5)
      .reduce((sum, die) => sum + die, 0);
  if (!lockedScores.has("6"))
    scores[6] = dice
      .filter((die) => die === 6)
      .reduce((sum, die) => sum + die, 0);

  let upperSum = 0;
  for (let key in scores) {
    if (key >= 1 && key <= 6) {
      upperSum += scores[key];
    }
  }

  if (upperSum >= 63) {
    scores.bonus = 35;
  } else {
    scores.bonus = 0;
  }

  const counts = Array.from({ length: 7 }, () => 0);
  for (let i = 0; i < dice.length; i++) {
    counts[dice[i]]++;
  }

  if (!lockedScores.has("threeofakind")) {
    scores.threeofakind = counts.some((count) => count >= 3)
      ? dice.reduce((sum, die) => sum + die, 0)
      : 0;
  }

  if (!lockedScores.has("fourofakind")) {
    scores.fourofakind = counts.some((count) => count >= 4)
      ? dice.reduce((sum, die) => sum + die, 0)
      : 0;
  }

  if (!lockedScores.has("fullHouse")) {
    scores.fullHouse =
      counts.some((count) => count === 2) && counts.some((count) => count === 3)
        ? 25
        : 0;
  }

  if (!lockedScores.has("yahtzee")) {
    scores.yahtzee = counts.some((count) => count === 5) ? 50 : 0;
  }

  let totalScore = 0;
  for (let key in scores) {
    if (scores[key] !== undefined) {
      totalScore += scores[key];
    }
  }

  document.getElementById("totalScore").innerText = totalScore;

  Object.keys(scores).forEach((key) => {
    const cell = document.getElementById(key);
    if (cell && !lockedScores.has(key)) {
      cell.innerText = scores[key] !== undefined ? scores[key] : "";
    }
  });
}

//vergrendelt een scorecategorie nadat de speler een score heeft geselecteerd voor die categorie
function lockScore(id) {
  if (!lockedScores.has(id) && !scoreSelected) {
    lockedScores.add(id);
    document.getElementById(id).classList.add("lockedScore");
    scoreSelected = true;
    rollsLeft = 3; // Reset rolls left for the next turn
    document.getElementById("rollButton").disabled = false;

    // Reset dice to 1 and clear scores
    dice = [1, 1, 1, 1, 1];
    lockedDice = [];
    for (let i = 1; i <= 5; i++) {
      const diceElement = document.getElementById(`die${i}`);
      diceElement.src = `dices/Dice_1.png`;
      diceElement.classList.remove("locked");
    }

    // Clear scores
    Object.keys(scores).forEach((key) => {
      if (!lockedScores.has(key)) {
        const cell = document.getElementById(key);
        if (cell) {
          cell.innerText = "";
        }
      }
    });

    // Update scores based on the new roll (all 1s)
    calculateScores();

    if (lockedScores.size === 13) {
      alert(
        "Game over! Final score: " +
          document.getElementById("totalScore").innerText
      );
    }
  }
}
